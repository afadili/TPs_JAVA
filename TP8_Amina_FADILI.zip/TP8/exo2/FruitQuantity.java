public abstract class FruitQuantity {
	private int quantity;
	public abstract int getPrice();

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}