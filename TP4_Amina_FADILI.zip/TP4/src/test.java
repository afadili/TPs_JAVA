import java.util.*;

public class test   
{  
     public static void main(String[] args) 
	{
        List<String> someList = new ArrayList<String>();
        someList.add("bidule");
        someList.add("machin");
        for (String item : someList) {
            System.out.println(item);
        }

	}
}